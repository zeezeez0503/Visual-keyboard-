# Import the Library
import cv2
import os # This mange the history file
from cvzone.HandTrackingModule import HandDetector
import numpy as np
import cvzone
from pynput.keyboard import Controller, Key
import time
from time import sleep
import pyautogui
import imutils
import pyttsx3
import re # For string manipulation
# Define a function to delete history file if it exists
def delete_history_file():
    if os.path.exists("history.txt"):
        os.remove("history.txt")
# Define a function to check if history box is clicked
def is_history_box_clicked(lmList):
    x1, y1, x2, y2 = 50, 425, 475, 475
    if x1 < lmList[8][0] < x2 and y1 < lmList[8][1] < y2:
        return True
    return False
# Capture video from default camera
cap = cv2.VideoCapture(0)
cap.set(3, 1280)  # Set width of video capture
cap.set(4, 720)   # Set height of video capture

# Create a HandDetector object with higher detection confidence and maximum number of hands set to 1
detector = HandDetector(detectionCon=0.85, maxHands=1)  # Make it more accurate
# Define a 2D list of keys for the virtual keyboard
keys = [["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "CLeaR"],
        ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "BACKSPACE"],
        ["A", "S", "D", "F", "G", "H", "J", "K", "L", ";", "ENTER"],
        ["Z", "X", "C", "V", "B", "N", "M", ",", ".", "/", "SPEAK"],
        ["SPACE", ]]

finalText = ""  # Create an empty string to store final text
historyText = ""  # Create an empty string to store last typed word
# Initialize a text-to-speech engine with rate and volume properties set
text_speech = pyttsx3.init()
text_speech.setProperty('rate', 125)
text_speech.setProperty('volume', 1.0)

keyboard = Controller()  # Create a keyboard object from the Controller class of pynput.keyboard module

button_size = [60, 60]  # Set the size of a button
backspace_size = [200, 60] # Set the size of the "Backspace
clear_size = [140, 60]  # Set the size of the "Clear" button

max_length = 25  # Define the maximum number of characters to display in the final text box
# Define a function to draw all the buttons
def drawAll(img, buttonList):
    for button in buttonList:
        x, y = button.pos
        w, h = button.size
        # Draw a rectangle filled with purple color around the button
        cvzone.cornerRect(img, (button.pos[0], button.pos[1], button.size[0], button.size[1]),
                          20, rt=0)
        cv2.rectangle(img, button.pos, (x + w, y + h), (255, 0, 255), cv2.FILLED)
        # Set the font size for the button text
        font_scale = 2 if button.text == "BACKSPACE" else 3
        # Set the font size for the "Clear" button to be bigger
        if button.text == "CLeaR":
            font_scale = 2.5  # Set the font size for "Clear" button to be bigger
        # Draw the button text on the rectangle with white color
        cv2.putText(img, button.text, (x + 10, y + 40),
                    cv2.FONT_HERSHEY_PLAIN, font_scale, (255, 255, 255), 4)
    return img

# Create a Button class to represent a button with position, size and text properties
class Button():
    def __init__(self, pos, text, size=[150, 150]):
        self.pos = pos
        self.size = size
        self.text = text


# Set the spacing between buttons
button_spacing = [85, 80]
buttonList = []
# Loop through the keys 2D list and create a Button object for each key with appropriate properties
for i in range(len(keys)):
    for j, key in enumerate(keys[i]):
        if key == "BACKSPACE":
            buttonList.append(Button([button_spacing[0] * j + 25, button_spacing[1] * i + 25], key, backspace_size))  # Adjust position and size for "Backspace" button
        elif key == "CLeaR":
            buttonList.append(Button([button_spacing[0] * j + 25, button_spacing[1] * i + 25], key, clear_size))  # Adjust position and size for "Clear" button
        elif key == "SPACE":
            buttonList.append(Button([button_spacing[0] * j + 139, button_spacing[1] * i + 25], key, [button_size[0]*10, button_size[1]])) # Adjust position and size for the "Space" button
        elif key == "ENTER":
            buttonList.append(Button([button_spacing[0] * j + 25, button_spacing[1] * i + 25], key, [button_size[0]*3, button_size[1]])) # Adjust position and size for the "Enter" button
        elif key == "SPEAK":
            buttonList.append(Button([button_spacing[0] * j + 25, button_spacing[1] * i + 25], key, backspace_size))
        else:
            buttonList.append(Button([button_spacing[0] * j + 25, button_spacing[1] * i + 25], key, button_size))  # Adjust position for other buttons

last_pressed = None      # Create a variable to store the last button pressed
last_pressed_time = 0    # Create a variable to store the time of last button press
click_delay = 0.2        # Increase this to make sure that really want to select that button
distance_threshold = 30  # Set the maximum distance between index finger and middle finger to be considered as clicking

# Start an infinite loop to capture frames from the video fee
while True:
    success, img = cap.read()
    img = cv2.flip(img, 1) # Flip the image horizontally
    img = detector.findHands(img)
    lmList, bboxInfo = detector.findPosition(img)
    img = drawAll(img, buttonList)


    if lmList:
        if is_history_box_clicked(lmList):
           finalText = display_history
           display_history = ""
        for button in buttonList:
            x, y = button.pos
            w, h = button.size

            # Check if the index finger tip is within the button boundary
            if x < lmList[8][0] < x + w and y < lmList[8][1] < y + h:
                # Draw a rectangle filled with purple color around the button with a little padding
                cv2.rectangle(img, (x - 5, y - 5), (x + w + 5, y + h + 5), (175, 0, 175), cv2.FILLED)
                # Set the font size for the button text
                font_scale = 2 if button.text == "BACKSPACE" else 3
                # Draw the button text on the rectangle with white color
                cv2.putText(img, button.text, (x + 10, y + 40),
                            cv2.FONT_HERSHEY_PLAIN, font_scale, (255, 255, 255), 4)
                # Calculate the distance between the index finger tip and the middle finger tip
                l, _, _ = detector.findDistance(8, 12, img, draw=False)

                # When clicked
                if l < distance_threshold:
                    # Get the current time
                    now = time.time()
                    # If a different button is pressed or it has been longer than the click delay since the last button press
                    if (last_pressed != button.text and (now - last_pressed_time) > click_delay) or (now - last_pressed_time) > click_delay * 2:
                        last_pressed = button.text
                        last_pressed_time = now

                        # Draw a green rectangle around the button to indicate it has been clicked
                        cv2.rectangle(img, button.pos, (x + w, y + h), (0, 255, 0), cv2.FILLED)
                        # Draw the button text on the rectangle with white color
                        cv2.putText(img, button.text, (x + 10, y + 40),
                                    cv2.FONT_HERSHEY_PLAIN, font_scale, (255, 255, 255), 4)
                        # Handle button presses or where we add the function
                        if button.text == "BACKSPACE":  # delete the previous text in the display
                            finalText = finalText[:-1]
                            keyboard.press(Key.backspace)
                            keyboard.release(Key.backspace)
                        elif button.text == "CLeaR":  # Clear all the text in display box
                            finalText = ""
                        elif button.text == "SPEAK":  # Make text speech with the finalText in the display box
                            text_speech.say(finalText)
                            text_speech.runAndWait()
                        elif button.text == "ENTER": # Make enter to me the exit program but it will save the last text in the display box
                            if finalText:
                                # Write the final text to the history file
                                with open("history.txt", "a") as f:
                                    f.write(finalText + "\n")
                                # Trim the final text to the maximum length (not to make it not out side the box) and display it in the text box
                                if len(finalText) > max_length:
                                    display_text = finalText[-max_length:]
                                else:
                                    display_text = finalText
                                # Display the trimmed final text on the image
                                cv2.putText(img, display_text, (60, 580), cv2.FONT_HERSHEY_PLAIN, 5, (255, 255, 255), 5)
                            # Release the camera and close all windows
                            cap.release()
                            cv2.destroyAllWindows()
                            exit()
                        else:
                            # Add a character to the final text if it's not longer than the maximum length allowed
                            if len(finalText) < max_length:  # Add max length check here
                                if button.text == "SPACE":
                                    finalText += " "
                                    keyboard.press(Key.space)
                                    keyboard.release(Key.space)
                                else:
                                    finalText += button.text
                                    keyboard.press(button.text)
                                    keyboard.release(button.text)
    # Create history.txt file if it doesn't exist
    if not os.path.isfile("history.txt"):
        with open("history.txt", "w") as f:
            pass
    # Display history from the history.txt file if it's not empty
    if os.path.getsize("history.txt") > 0:
        with open("history.txt", "r") as f:
            lines = f.readlines()
            last_line = lines[-1].strip()
            if len(last_line) > max_length:
                display_history = last_line[-max_length:]
            else:
                display_history = last_line
            # Draw a rectangle on the image to display history
            cv2.rectangle(img, (50, 425), (475, 475), (175, 0, 175), cv2.FILLED)  # Change the position and size of the display box
            # Display history text on the image
            cv2.putText(img, display_history, (60, 460), cv2.FONT_HERSHEY_PLAIN, 3, (255, 255, 255), 5)

    # Draw a rectangle on the image to display the final text
    cv2.rectangle(img, (50, 500), (1150, 700), (175, 0, 175), cv2.FILLED)
    # Initialize cursor position, max width, max characters, and character count
    cursor_x, cursor_y = 60, 580
    max_width = 1090
    max_chars = 17
    char_count = 0
    # Display the final text on the image, character by character
    for i, char in enumerate(finalText):
        cv2.putText(img, char, (cursor_x, cursor_y), cv2.FONT_HERSHEY_PLAIN, 5, (255, 255, 255), 5)
        text_width, _ = cv2.getTextSize(char, cv2.FONT_HERSHEY_PLAIN, 5, 5)
        cursor_x += text_width[0]
        char_count += 1
        # Move the cursor to a new line if the maximum number of characters per line is reached
        if char_count >= max_chars:
            cursor_x = 60
            cursor_y += 100
            char_count = 0
        # Move the cursor to a new line if the current character is a newline character
        if char == "\n":
            cursor_x = 60
            cursor_y += 100
            char_count = 0
    # Initialize cursor position, thickness, height, and color
    cursor_pos = (cursor_x, cursor_y - 40)
    cursor_thickness = 2
    cursor_height = 30
    cursor_color = (255, 255, 255)
    # Draw the cursor on the image at the specified position
    cv2.line(img, cursor_pos, (cursor_pos[0], cursor_pos[1] + cursor_height), cursor_color, cursor_thickness)
    # Display the modified image
    cv2.imshow("Image", img)
    # Wait for a key press event and store the ASCII value of the key
    key = cv2.waitKey(1)
    # Check if the 'q' key is pressed
    if key == ord('q'):
        # Append the final text to the history.txt file (If press q will delete the history text file)
        with open("history.txt", "a") as f:
            f.write(finalText + "\n")
        # Take a screenshot and save it to the specified path
        myScreenshot = pyautogui.screenshot()
        myScreenshot.save(r'/Users/mhoosamrchunn/Desktop/1.png')


        sleep(0.5) # Add a small delay before deleting the history file
        delete_history_file()
        break
# Release the camera and close all windows
cap.release()
cv2.destroyAllWindows()



